<table class="table table-bordered">
    <thead>
    <tr>
        <th scope="col">Shop Name</th>
        <th scope="col">Total Sales Item</th>
        <th scope="col" width="35">Details</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($shop->shop_name); ?></td>
            <td><?php echo e($shop->total_item == null ? 0 : $shop->total_item); ?></td>
            <td class="text-center">
                <?php if($shop->total_item): ?>
                    <img class="deatails_up" onclick="detailsOpen(1,<?php echo e($key); ?>,<?php echo e($shop->id); ?>)" id="deatails_up<?php echo e($key); ?>"
                         style="cursor:pointer;"
                         src="<?php echo e(asset('icon/up.png')); ?>" width="30">
                    <img class="deatails_down" onclick="detailsOpen(0,<?php echo e($key); ?>,<?php echo e($shop->id); ?>)" id="deatails_down<?php echo e($key); ?>"
                         style="cursor:pointer;"
                         src="<?php echo e(asset('icon/down.svg')); ?>" width="30">
                <?php endif; ?>
            </td>
        </tr>
        <tr class="details-tr details-tr<?php echo e($key); ?>" >
            <td colspan="4" id="details-table<?php echo e($key); ?>">

            </td>
        </tr>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($shops->count()): ?>
        <td colspan="4">Larry the Bird</td>
    <?php endif; ?>
    </tbody>
</table>
<script>
    $('.deatails_up').hide()
    $('.details-tr').hide()
</script>
<?php /**PATH F:\Xampp\htdocs\InterView\CompanySales\resources\views/CliectsShop/shop.blade.php ENDPATH**/ ?>