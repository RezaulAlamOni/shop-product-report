<table class="table table-bordered">
    <thead>
    <tr>
        <th scope="col">Product Name</th>
        <th scope="col">Product Category</th>
        <th scope="col">No of sale</th>
        <th scope="col">Total Price</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($product->product_name); ?></td>
            <td class="text-capitalize"><?php echo e($product->product_cat); ?></td>
            <td class="text-capitalize"><?php echo e($product->total_product); ?></td>
            <td class="text-capitalize"><?php echo e($product->price); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH F:\Xampp\htdocs\InterView\CompanySales\resources\views/Products/products.blade.php ENDPATH**/ ?>